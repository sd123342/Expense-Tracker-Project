# Expense Tracker (Django)

Track income and spending, see where your money goes each month, and export to CSV.

## Run it

```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

Open http://127.0.0.1:8000/ and create an account. Starter categories are added automatically.
Optional: `python manage.py createsuperuser` for the admin at /admin/.

## Features
- Sign up, log in, log out (each user only sees their own data)
- Add, edit, delete transactions; custom income/expense categories
- Monthly dashboard: balance, income, spending, category breakdown
- Filter by month, type, category; download CSV
- Amounts shown in ₹ with Indian digit grouping (change `CURRENCY_SYMBOL` in `config/settings.py`)

## Structure
```
config/            project settings and root urls
tracker/models.py  Category, Transaction
tracker/views.py   dashboard, CRUD, CSV export
tracker/templates/ HTML pages
tracker/tests.py   run with: python manage.py test
```
