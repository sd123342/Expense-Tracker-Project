from datetime import date
from decimal import Decimal

from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse

from .models import Category, Transaction
from .templatetags.money import money


class ExpenseTrackerTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user('asha', password='pw12345!x')
        self.other = User.objects.create_user('ravi', password='pw12345!x')
        self.food = Category.objects.create(user=self.user, name='Food', kind='expense')
        self.salary = Category.objects.create(user=self.user, name='Salary', kind='income')
        self.client.login(username='asha', password='pw12345!x')

    def test_login_required(self):
        self.client.logout()
        r = self.client.get(reverse('dashboard'))
        self.assertEqual(r.status_code, 302)
        self.assertIn('/accounts/login/', r.url)

    def test_signup_creates_default_categories(self):
        self.client.logout()
        r = self.client.post(reverse('signup'), {
            'username': 'newbie', 'password1': 'Str0ng-pass!', 'password2': 'Str0ng-pass!'})
        self.assertRedirects(r, reverse('dashboard'))
        self.assertTrue(Category.objects.filter(user__username='newbie').count() >= 6)

    def test_dashboard_totals_and_breakdown(self):
        Transaction.objects.create(user=self.user, category=self.salary, amount=50000, date=date(2026, 10, 1))
        Transaction.objects.create(user=self.user, category=self.food, amount=1500, date=date(2026, 10, 5))
        Transaction.objects.create(user=self.user, category=self.food, amount=999, date=date(2026, 9, 5))
        r = self.client.get(reverse('dashboard'), {'month': '2026-10'})
        self.assertEqual(r.context['income'], Decimal('50000'))
        self.assertEqual(r.context['expense'], Decimal('1500'))
        self.assertEqual(r.context['balance'], Decimal('48500'))
        self.assertEqual(r.context['breakdown'][0]['percent'], 100)

    def test_create_edit_delete(self):
        r = self.client.post(reverse('transaction_create'), {
            'category': self.food.pk, 'amount': '250.50', 'date': '2026-10-10', 'note': 'Lunch'})
        self.assertRedirects(r, reverse('transaction_list'))
        t = Transaction.objects.get()
        self.client.post(reverse('transaction_edit', args=[t.pk]), {
            'category': self.food.pk, 'amount': '300', 'date': '2026-10-10', 'note': 'Lunch+tea'})
        t.refresh_from_db()
        self.assertEqual(t.amount, Decimal('300'))
        self.client.post(reverse('transaction_delete', args=[t.pk]))
        self.assertEqual(Transaction.objects.count(), 0)

    def test_rejects_non_positive_amount(self):
        r = self.client.post(reverse('transaction_create'), {
            'category': self.food.pk, 'amount': '-5', 'date': '2026-10-10'})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(Transaction.objects.count(), 0)

    def test_users_cannot_touch_each_others_data(self):
        t = Transaction.objects.create(user=self.other, category=Category.objects.create(
            user=self.other, name='X', kind='expense'), amount=10)
        self.assertEqual(self.client.get(reverse('transaction_edit', args=[t.pk])).status_code, 404)
        self.assertEqual(self.client.post(reverse('transaction_delete', args=[t.pk])).status_code, 404)
        # cannot post another user's category
        r = self.client.post(reverse('transaction_create'), {
            'category': t.category.pk, 'amount': '5', 'date': '2026-10-10'})
        self.assertEqual(r.status_code, 200)

    def test_category_with_transactions_is_protected(self):
        Transaction.objects.create(user=self.user, category=self.food, amount=10)
        self.client.post(reverse('category_delete', args=[self.food.pk]))
        self.assertTrue(Category.objects.filter(pk=self.food.pk).exists())

    def test_filters_and_csv(self):
        Transaction.objects.create(user=self.user, category=self.food, amount=10, date=date(2026, 10, 2))
        Transaction.objects.create(user=self.user, category=self.salary, amount=99, date=date(2026, 10, 3))
        r = self.client.get(reverse('transaction_list'), {'kind': 'income'})
        self.assertEqual(len(r.context['transactions']), 1)
        r = self.client.get(reverse('transaction_list'), {'export': 'csv'})
        self.assertEqual(r['Content-Type'], 'text/csv')
        self.assertIn('Food', r.content.decode())

    def test_money_filter_indian_grouping(self):
        self.assertEqual(money(Decimal('1234567.5')), '₹12,34,567.50')
        self.assertEqual(money(Decimal('-999')), '-₹999.00')
        self.assertEqual(money(0), '₹0.00')

    def test_pages_render(self):
        for name in ['dashboard', 'transaction_list', 'transaction_create', 'category_list']:
            self.assertEqual(self.client.get(reverse(name)).status_code, 200, name)
