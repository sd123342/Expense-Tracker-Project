from django.conf import settings
from django.db import models
from django.urls import reverse
from django.utils import timezone


class Category(models.Model):
    EXPENSE = 'expense'
    INCOME = 'income'
    KIND_CHOICES = [(EXPENSE, 'Expense'), (INCOME, 'Income')]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='categories')
    name = models.CharField(max_length=50)
    kind = models.CharField(max_length=7, choices=KIND_CHOICES, default=EXPENSE)

    class Meta:
        ordering = ['name']
        verbose_name_plural = 'categories'
        constraints = [
            models.UniqueConstraint(fields=['user', 'name', 'kind'], name='unique_category_per_user_kind'),
        ]

    def __str__(self):
        return self.name


class Transaction(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='transactions')
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name='transactions')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    date = models.DateField(default=timezone.localdate)
    note = models.CharField(max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date', '-created_at']

    def __str__(self):
        return f'{self.category} {self.amount} on {self.date}'

    @property
    def kind(self):
        return self.category.kind

    def get_absolute_url(self):
        return reverse('transaction_list')


DEFAULT_CATEGORIES = [
    ('Food & Dining', Category.EXPENSE), ('Transport', Category.EXPENSE),
    ('Rent & Bills', Category.EXPENSE), ('Shopping', Category.EXPENSE),
    ('Health', Category.EXPENSE), ('Entertainment', Category.EXPENSE),
    ('Salary', Category.INCOME), ('Other income', Category.INCOME),
]
