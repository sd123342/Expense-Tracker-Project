import csv
from datetime import date
from decimal import Decimal

from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.db.models import ProtectedError, Sum
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render

from .forms import CategoryForm, SignUpForm, TransactionForm
from .models import DEFAULT_CATEGORIES, Category, Transaction


def signup(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    form = SignUpForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.save()
        Category.objects.bulk_create([Category(user=user, name=n, kind=k) for n, k in DEFAULT_CATEGORIES])
        login(request, user)
        messages.success(request, 'Welcome! We added a few starter categories for you.')
        return redirect('dashboard')
    return render(request, 'registration/signup.html', {'form': form})


def _parse_month(value):
    """Turn '2026-10' into a date(2026, 10, 1); fall back to the current month."""
    try:
        year, month = value.split('-')
        return date(int(year), int(month), 1)
    except (AttributeError, ValueError):
        today = date.today()
        return date(today.year, today.month, 1)


def _month_neighbours(first):
    prev = date(first.year - 1, 12, 1) if first.month == 1 else date(first.year, first.month - 1, 1)
    nxt = date(first.year + 1, 1, 1) if first.month == 12 else date(first.year, first.month + 1, 1)
    return prev, nxt


@login_required
def dashboard(request):
    first = _parse_month(request.GET.get('month'))
    prev_month, next_month = _month_neighbours(first)
    month_qs = Transaction.objects.filter(
        user=request.user, date__gte=first, date__lt=next_month
    ).select_related('category')

    income = month_qs.filter(category__kind=Category.INCOME).aggregate(t=Sum('amount'))['t'] or Decimal('0')
    expense = month_qs.filter(category__kind=Category.EXPENSE).aggregate(t=Sum('amount'))['t'] or Decimal('0')

    breakdown = list(
        month_qs.filter(category__kind=Category.EXPENSE)
        .values('category__name').annotate(total=Sum('amount')).order_by('-total')
    )
    for row in breakdown:
        row['percent'] = round(row['total'] / expense * 100) if expense else 0

    return render(request, 'tracker/dashboard.html', {
        'month': first, 'prev_month': prev_month, 'next_month': next_month,
        'income': income, 'expense': expense, 'balance': income - expense,
        'breakdown': breakdown, 'recent': month_qs[:5],
    })


@login_required
def transaction_list(request):
    qs = Transaction.objects.filter(user=request.user).select_related('category')
    month = request.GET.get('month', '')
    category = request.GET.get('category', '')
    kind = request.GET.get('kind', '')
    if month:
        first = _parse_month(month)
        qs = qs.filter(date__gte=first, date__lt=_month_neighbours(first)[1])
    if category.isdigit():
        qs = qs.filter(category_id=category)
    if kind in (Category.INCOME, Category.EXPENSE):
        qs = qs.filter(category__kind=kind)

    if request.GET.get('export') == 'csv':
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="transactions.csv"'
        writer = csv.writer(response)
        writer.writerow(['Date', 'Type', 'Category', 'Amount', 'Note'])
        for t in qs:
            writer.writerow([t.date, t.kind, t.category.name, t.amount, t.note])
        return response

    return render(request, 'tracker/transaction_list.html', {
        'transactions': qs,
        'categories': Category.objects.filter(user=request.user),
        'filters': {'month': month, 'category': category, 'kind': kind},
    })


@login_required
def transaction_create(request):
    form = TransactionForm(request.POST or None, user=request.user)
    if request.method == 'POST' and form.is_valid():
        obj = form.save(commit=False)
        obj.user = request.user
        obj.save()
        messages.success(request, 'Transaction added.')
        return redirect('transaction_list')
    return render(request, 'tracker/transaction_form.html', {'form': form, 'title': 'Add transaction'})


@login_required
def transaction_edit(request, pk):
    obj = get_object_or_404(Transaction, pk=pk, user=request.user)
    form = TransactionForm(request.POST or None, instance=obj, user=request.user)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Changes saved.')
        return redirect('transaction_list')
    return render(request, 'tracker/transaction_form.html', {'form': form, 'title': 'Edit transaction'})


@login_required
def transaction_delete(request, pk):
    obj = get_object_or_404(Transaction, pk=pk, user=request.user)
    if request.method == 'POST':
        obj.delete()
        messages.success(request, 'Transaction deleted.')
        return redirect('transaction_list')
    return render(request, 'tracker/confirm_delete.html', {'object': obj, 'what': 'transaction'})


@login_required
def category_list(request):
    form = CategoryForm(request.POST or None, user=request.user)
    if request.method == 'POST' and form.is_valid():
        obj = form.save(commit=False)
        obj.user = request.user
        obj.save()
        messages.success(request, 'Category added.')
        return redirect('category_list')
    categories = Category.objects.filter(user=request.user)
    return render(request, 'tracker/category_list.html', {'form': form, 'categories': categories})


@login_required
def category_delete(request, pk):
    obj = get_object_or_404(Category, pk=pk, user=request.user)
    if request.method == 'POST':
        try:
            obj.delete()
            messages.success(request, 'Category deleted.')
        except ProtectedError:
            messages.error(request, f'"{obj.name}" has transactions. Move or delete them first.')
        return redirect('category_list')
    return render(request, 'tracker/confirm_delete.html', {'object': obj, 'what': 'category'})
