from decimal import Decimal

from django import template
from django.conf import settings

register = template.Library()


def _indian_group(integer_part: str) -> str:
    """12345678 -> 1,23,45,678"""
    if len(integer_part) <= 3:
        return integer_part
    head, tail = integer_part[:-3], integer_part[-3:]
    groups = []
    while len(head) > 2:
        groups.insert(0, head[-2:])
        head = head[:-2]
    if head:
        groups.insert(0, head)
    return ','.join(groups) + ',' + tail


@register.filter
def money(value):
    """Format a number as ₹1,23,456.00"""
    try:
        value = Decimal(value)
    except Exception:
        return value
    sign = '-' if value < 0 else ''
    whole, _, frac = f'{abs(value):.2f}'.partition('.')
    return f'{sign}{settings.CURRENCY_SYMBOL}{_indian_group(whole)}.{frac}'
