from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from .models import Category, Transaction


class SignUpForm(UserCreationForm):
    class Meta:
        model = User
        fields = ('username',)


class TransactionForm(forms.ModelForm):
    class Meta:
        model = Transaction
        fields = ['category', 'amount', 'date', 'note']
        widgets = {'date': forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d')}

    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['category'].queryset = Category.objects.filter(user=user)
        self.fields['amount'].widget.attrs.update({'min': '0.01', 'step': '0.01', 'inputmode': 'decimal'})

    def clean_amount(self):
        amount = self.cleaned_data['amount']
        if amount <= 0:
            raise forms.ValidationError('Enter an amount greater than zero.')
        return amount


class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ['name', 'kind']

    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.user = user

    def clean(self):
        data = super().clean()
        name, kind = data.get('name'), data.get('kind')
        if name and kind and Category.objects.filter(user=self.user, name__iexact=name, kind=kind).exclude(pk=self.instance.pk).exists():
            raise forms.ValidationError(f'You already have a {kind} category called "{name}".')
        return data
